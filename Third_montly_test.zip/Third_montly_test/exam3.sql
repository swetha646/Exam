use Database2;
select * from [dbo].[Sales_Data$];

--qs1--
select State,count(Distinct OrderID) as Total_orders, Sum(Quantity) as Totalquantity,
Sum(NetSales) as TotalNetSales,Sum(Profit) as TotalProfit, 
Sum(NetSales)/ Count(Distinct OrderID) as averageordervalue
from [dbo].[Sales_Data$] where OrderStatus ='Completed' group by State 
having Sum(NetSales)>1000000 order by Sum(NetSales) desc;

--qs2--
with customersales as ( 
select CustomerID,CustomerName,sum(NetSales) as Totalsales from [dbo].[Sales_Data$] where OrderStatus ='Completed' 
group by customerID,CustomerName )
select top 5 CustomerID,CustomerName,Totalsales from customersales order by Totalsales desc;

--q3--
with Statesales as 
( 
select State,sum(NetSales) as Totalsales 
from [dbo].[Sales_Data$] where OrderStatus ='Completed' group by State
)
select State, Totalsales,RANK() OVER (Order BY Totalsales desc) as salesrank 
from Statesales order by salesrank;