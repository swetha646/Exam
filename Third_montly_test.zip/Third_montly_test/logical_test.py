#1

data = [12,7,12,5,7,9,5,12,9,7,15]
duplicate = []
for i in data:
    if data.count(i)>1 and i not in duplicate:
        duplicate.append(i)
print("Duplicate numbers are:")
for i in duplicate :
    print(i, "-->",data.count(i))

#2
ids = [1,2,3,4,5,7,8,9,10]
for i in range(1,11):
    if i not in ids:
        print("missing id is :",i)